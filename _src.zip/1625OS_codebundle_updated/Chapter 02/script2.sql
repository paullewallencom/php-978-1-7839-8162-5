select SHA1("anystring");
