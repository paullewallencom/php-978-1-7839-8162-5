call p_insertStudents("James", "Price",
"11900 Hobby course ct.", "Austin", "TX", "78757",
"james.price", "jamesprice", @student_id);

select @student_id;