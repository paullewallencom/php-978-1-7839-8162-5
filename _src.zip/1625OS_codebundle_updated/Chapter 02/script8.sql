alter table students
change student_id student_id int not null
auto_increment primary key