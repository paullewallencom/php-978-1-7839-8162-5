select first_name, last_name, username, password
from students;