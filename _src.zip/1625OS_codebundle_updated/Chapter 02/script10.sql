insert into students(first_name, last_name, address,
city, state, zip_code, username, password)
values("Patrick", "Smith", "911A Clopper Rd", "Gburg", "MD", "20078",
"patrick.smith", SHA1("patricksmith"));
