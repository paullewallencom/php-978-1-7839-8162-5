insert into students(username)
values("richard.roe"); --richard.roe already exists