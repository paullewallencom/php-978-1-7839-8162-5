select fn_getFullName("john.doe"); -- works

select fn_getFullName("john.do"); -- does not work