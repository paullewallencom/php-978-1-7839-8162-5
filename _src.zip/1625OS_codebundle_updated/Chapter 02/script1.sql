alter table students
add column username varchar(45) not null,
add column password varchar(40) not null;
