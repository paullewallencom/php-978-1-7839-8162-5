select student_id, first_name, last_name,
username from students;