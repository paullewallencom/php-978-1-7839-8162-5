<?php
/*
* Explanation of how list() works
*
*/
list($one, $two, $three) = [1, 2, 3];

echo $one.' '.$two.' '.$three."\n";

?>
