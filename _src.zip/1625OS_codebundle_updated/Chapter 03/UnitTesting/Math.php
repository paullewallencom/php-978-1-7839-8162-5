<?php

class Math{

	/**
	* returns the sum of two numbers
	**/
	function add($a, $b){

		return $a + $b;

	}

}

?>
