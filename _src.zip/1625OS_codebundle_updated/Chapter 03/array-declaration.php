<?php

/**
* Array declaration before PHP 5.4
*
*/

$arr = array(1,2,3,4);

//Print an element to the screen
echo $arr[0]."\n";

/**
* Array declaration with PHP 5.4 or greater
*
*/

$arr2 = [1,2,3,4];

//Print an element to the screen
echo $arr2[0]."\n";

?>
