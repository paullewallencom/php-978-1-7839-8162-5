<?php

	class ConsDesc{
		/**
		* Constructor
		*/
		public function __construct(){
			// initialize variables
			// open database connections
			// open file handles
		}

		/**
		* Destructor
		*/
		public function __destruct(){
			// close database connections
			// close file handles
		}
	}

?>