<?php
	interface IAnimal{
		function run();
		function communicate();
	}
?>