<footer class="footer">
	Page Footer
</footer>
</body>
</html>
