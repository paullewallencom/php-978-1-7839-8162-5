<!DOCTYPE html>
<html>
        <head>
                <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                <title>Student Portal</title>
		<link type="text/css" rel="stylesheet" href="<?=BASE_URL;?>assets/css/styles.css">
	</head>
	<body>
		<header>
                        <p>Contact Us | About Us | Home</p>
                </header>

