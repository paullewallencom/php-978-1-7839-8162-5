<?php
define('LIBRARY', 'lib/');
define('BASE_URL', 'http://localhost/student-portal/');

define('DB_VENDOR','mysql');
define('DB_HOST','localhost');
define('DB_NAME','course_registry');
define('DB_USR','root');
define('DB_PWD','admin');
