select first_name from students;

select first_name from students
order by first_name;

select first_name from students
order by first_name desc;

select student_id, first_name from students
order by student_id, first_name;
