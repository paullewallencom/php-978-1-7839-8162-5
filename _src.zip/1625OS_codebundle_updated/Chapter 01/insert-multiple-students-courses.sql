insert into students_courses(
	student_id, course_id)
values
	(1,1), -- Student id 1 & Course id 1
	(1,2), -- Student id 1 & Course id 2
	(2,2), -- Student id 2 & Course id 2
	(3,1); -- Student id 3 & Course id 1