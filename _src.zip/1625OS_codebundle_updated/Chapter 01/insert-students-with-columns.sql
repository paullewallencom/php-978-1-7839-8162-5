insert into students(
	student_id,
	first_name,
	last_name,
	address,
	city,
	state,
	zip_code
)
values( 2,
	"Jane",
	"Dane",
	"49 Puritan Ln",
	"Stamford",
	"CT",
	"06906"
);
