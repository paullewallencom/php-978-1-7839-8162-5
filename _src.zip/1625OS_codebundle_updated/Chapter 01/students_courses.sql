create table students_courses(
	course_id int,
	student_id int
);