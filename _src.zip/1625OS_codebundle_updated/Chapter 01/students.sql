create table students(
	student_id int,
	first_name varchar(60),
	last_name varchar(60),
	address varchar(255),
	city varchar(40),
	state char(2),
	zip_code char(5)
);
