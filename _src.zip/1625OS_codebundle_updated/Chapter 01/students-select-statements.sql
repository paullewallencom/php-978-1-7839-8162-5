select * from students;

select student_id, first_name, last_name from students;

select student_id, first_name, last_name 
from students limit 1;

