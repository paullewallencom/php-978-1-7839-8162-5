select student_id, first_name, last_name
from students
where last_name="Dane";

select student_id, first_name, last_name
from students
where student_id=1;

select student_id, first_name, last_name
from students
where student_id>1;

select student_id, first_name, last_name
from students
where student_id<4

select student_id, first_name, last_name
from students
where student_id between 1 and 4;