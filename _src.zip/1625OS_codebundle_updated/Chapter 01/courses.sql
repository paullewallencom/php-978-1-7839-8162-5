create table courses(
	course_id int,
	name varchar(60),
	description varchar(255)
);