insert into courses(
	course_id, name, description
)
values(1, "CS-101",
	"Introduction to Computer Science");
	
insert into courses(
	course_id, name, description
)
values(2, "CE-101",
	"Introduction to Computer Engineering");	