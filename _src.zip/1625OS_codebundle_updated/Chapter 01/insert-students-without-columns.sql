insert into students
values( 1,
	"John",
	"Doe",
	"3225 Woodland Park St",
	"Houston",
	"TX",
	"77082"
);
