insert into students(
	student_id,
	first_name,
	last_name,
	address,
	city,
	state,
	zip_code
)
values( 3,
	"Richard",
	"Roe",
	NULL,
	"Atlanta",
	"GA",
	"30328"
);
